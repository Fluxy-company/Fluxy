package school.sptech.iefcbackend.web.dto.relatorio;

import lombok.Data;

@Data
public class DepoimentoDTO {
    private String texto;
}
