package school.sptech.iefcbackend.usecase.projeto;

import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.Projeto;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.ProjetoJpaRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class ProjetoService {

    private final ProjetoJpaRepository ProjetoJpaRepository;

    public ProjetoService(ProjetoJpaRepository ProjetoJpaRepository) {
        this.ProjetoJpaRepository = ProjetoJpaRepository;
    }

    public Projeto salvarProjeto(Projeto projeto) {
        if (projeto.getEmpresa() == null || projeto.getEmpresa().getId() == null) {
            throw new RecursoNaoEncontradoException("Empresa não informada ou inválida");
        }
        return ProjetoJpaRepository.save(projeto);
    }

    public List<Projeto> buscarTodos() { return ProjetoJpaRepository.findAll(); }

    public Projeto buscarProjetoPorNome(String nome){
        return ProjetoJpaRepository.findByNome(nome).orElseThrow(
            () -> new RecursoNaoEncontradoException("Não há nenhum projeto com este nome.")
        );
    }

    public List<Projeto> buscarProjetoPorDataInicio(LocalDate dataInicio){
        List<Projeto> projetos = ProjetoJpaRepository.findAllByDataInicio(dataInicio);

        if (projetos.isEmpty()) {
            throw new RecursoNaoEncontradoException("Nenhum projeto foi iniciado na data informada.");
        }

        return projetos;
    }

    public List<Projeto> buscarProjetoPorStatus(String status){
        Projeto.StatusProjeto statusEnum;
        try {
            statusEnum = Projeto.StatusProjeto.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Status inválido: " + status);
        }
        List<Projeto> projetos = ProjetoJpaRepository.findAllByStatus(statusEnum);


        if (projetos.isEmpty()) {
            throw new RecursoNaoEncontradoException("Nenhum projeto foi encontrado com o status informado.");
        }

        return projetos;
    }

    public Projeto atualizarPorId(Long id, Projeto projeto){
        Projeto projetoEntity = ProjetoJpaRepository.findById(id).orElseThrow(
            () -> new RecursoNaoEncontradoException("Nenhum projeto foi encontrado com essa identificação.")
        );

        projetoEntity.setNome(projeto.getNome());
        projetoEntity.setDescricao(projeto.getDescricao());
        projetoEntity.setDataInicio(projeto.getDataInicio());
        projetoEntity.setDataFim(projeto.getDataFim());
        projetoEntity.setStatus(projeto.getStatus());

        return ProjetoJpaRepository.save(projetoEntity);
    }

    public void deletarPorId(Long id){
        Projeto projetoEntity = ProjetoJpaRepository.findById(id).orElseThrow(
            () -> new RecursoNaoEncontradoException("Nenhum projeto foi encontrado com essa identificação.")
        );
        ProjetoJpaRepository.delete(projetoEntity);
    }
}
