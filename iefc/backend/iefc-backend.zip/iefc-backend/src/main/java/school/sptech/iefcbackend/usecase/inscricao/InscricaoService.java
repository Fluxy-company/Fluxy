package school.sptech.iefcbackend.usecase.inscricao;

import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.Curso;
import school.sptech.iefcbackend.domain.entity.Inscricao;
import school.sptech.iefcbackend.domain.entity.Usuario;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.CursoJpaRepository;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.InscricaoJpaRepository;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.UsuarioJpaRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class InscricaoService {

    private final InscricaoJpaRepository repository;
    private final UsuarioJpaRepository UsuarioJpaRepository;
    private final CursoJpaRepository CursoJpaRepository;

    public InscricaoService(InscricaoJpaRepository repository, UsuarioJpaRepository UsuarioJpaRepository, CursoJpaRepository CursoJpaRepository) {
        this.repository = repository;
        this.UsuarioJpaRepository = UsuarioJpaRepository;
        this.CursoJpaRepository = CursoJpaRepository;
    }

    public Inscricao inscrever(Long usuarioId, Long cursoId) {
        if (repository.existsByUsuarioIdAndCursoId(usuarioId, cursoId)) {
            return repository.findByUsuarioIdAndCursoId(usuarioId, cursoId).get();
        }

        Usuario usuario = UsuarioJpaRepository.findById(usuarioId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Usuário não encontrado"));

        Curso curso = CursoJpaRepository.findById(cursoId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Curso não encontrado"));

        Inscricao inscricao = new Inscricao();
        inscricao.setUsuario(usuario);
        inscricao.setCurso(curso);
        inscricao.setDataInscricao(LocalDate.now());

        return repository.save(inscricao);
    }

    public List<Inscricao> listarPorUsuario(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId);
    }

    public boolean estaInscrito(Long usuarioId, Long cursoId) {
        return repository.existsByUsuarioIdAndCursoId(usuarioId, cursoId);
    }

    public void cancelar(Long usuarioId, Long cursoId) {
        Inscricao inscricao = repository.findByUsuarioIdAndCursoId(usuarioId, cursoId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Inscrição não encontrada"));
        repository.delete(inscricao);
    }
}
