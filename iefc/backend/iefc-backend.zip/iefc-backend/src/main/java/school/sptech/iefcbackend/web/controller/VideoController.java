package school.sptech.iefcbackend.web.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import school.sptech.iefcbackend.domain.entity.Video;
import school.sptech.iefcbackend.usecase.video.VideoService;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/videos")
@Tag(name = "Video", description = "Controller para salvar, editar e deletar os dados videos.")
public class VideoController {

    private final VideoService service;

    public VideoController(VideoService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAnyAuthority('SCOPE_ROLE_ALUNO', 'SCOPE_ROLE_COLABORADOR', 'SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Busca todos os videos", description = "Método que busca todos os videos")
    @ApiResponse(responseCode = "200", description = "Sucesso")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<List<Video>> listarTodos() {
        return ResponseEntity.ok(service.buscarTodos());
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Para salvar videos", description = "Método para salvar videos")
    @ApiResponse(responseCode = "201", content = @Content(schema = @Schema(implementation = Video.class)), description = "Video salvo com sucesso")
    @ApiResponse(responseCode = "404", description = "Nenhum video encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Video> salvarVideo(@RequestBody Video video) {
        Video saved = service.salvarVideo(video);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Edita video pelo id", description = "Método para editar os dados do video")
    @ApiResponse(responseCode = "200", description = "Video editado com sucesso")
    @ApiResponse(responseCode = "400", description = "Não encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Video> atualizarEventoPorId(@PathVariable Long id, @RequestBody Video video) {
        return ResponseEntity.ok(service.atualizarPeloId(id, video));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Deletar video pelo id", description = "Método que deleta os videos pelo id")
    @ApiResponse(responseCode = "204", description = "Video deletado com sucesso")
    @ApiResponse(responseCode = "404", description = "Sem video nesse id")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Void> deletarPorId(@PathVariable Long id) {
        service.deletarPorId(id);
        return ResponseEntity.noContent().build();
    }

}
