package school.sptech.iefcbackend.usecase.empresa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.Empresa;
import school.sptech.iefcbackend.domain.entity.Usuario;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.EmpresaJpaRepository;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.UsuarioJpaRepository;

import java.util.List;

@Service
public class EmpresaService {

    @Autowired
    EmpresaJpaRepository EmpresaJpaRepository;

    @Autowired
    UsuarioJpaRepository UsuarioJpaRepository;

    public void salvarEmpresa(Empresa empresa){
        empresa.setUsuario(buscarUsuarioValido(empresa.getUsuario()));
        EmpresaJpaRepository.save(empresa);
    }

    public List<Empresa> buscarTodos() {
        return EmpresaJpaRepository.findAll();
    }

    public Empresa buscarEmpresaPorCnpj(String cnpj){
        return EmpresaJpaRepository.findByCnpj(cnpj).orElseThrow(
        () -> new RecursoNaoEncontradoException("Cnpj  não encontrado!")
        );
    }

    public void atualizarPorId(Long id, Empresa empresa){
        Empresa empresaEntity = EmpresaJpaRepository.findById(id).orElseThrow(()  
        -> new RecursoNaoEncontradoException("Empresa não encontrada"));
        empresaEntity.setNome(empresa.getNome());
        empresaEntity.setCnpj(empresa.getCnpj());
        empresaEntity.setTelefone(empresa.getTelefone());
        empresaEntity.setUsuario(buscarUsuarioValido(empresa.getUsuario()));

        EmpresaJpaRepository.save(empresaEntity);
    }

    public void deletarPorId(Long id){
        Empresa entity = EmpresaJpaRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Sem registros nesse id"));
        EmpresaJpaRepository.delete(entity);
    }

    private Usuario buscarUsuarioValido(Usuario usuario){
        if (usuario == null || usuario.getId() == null) {
            return null;
        }
        Long idUsuario = usuario.getId();
        if (idUsuario <= 0) {
            throw new RecursoNaoEncontradoException("Usuario invalido para vinculo na empresa");
        }
        return UsuarioJpaRepository.findById(idUsuario)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Usuario não encontrado para vincular na empresa"));
    }
}
