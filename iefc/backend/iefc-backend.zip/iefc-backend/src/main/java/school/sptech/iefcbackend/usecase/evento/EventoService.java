package school.sptech.iefcbackend.usecase.evento;

import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.Eventos;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.EventoJpaRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class EventoService {

    private final EventoJpaRepository EventoJpaRepository;

    public EventoService(EventoJpaRepository EventoJpaRepository) {
        this.EventoJpaRepository = EventoJpaRepository;
    }

    public Eventos criarEvento(Eventos evento){
        if (evento.getEmpresa() == null || evento.getEmpresa().getId() == null) {
            throw new RecursoNaoEncontradoException("Empresa não informada ou inválida");
        }
        return EventoJpaRepository.save(evento);
    }

    public List<Eventos> buscarTodos(){
        return EventoJpaRepository.findAll();
    }

    public List<Eventos> buscarEventoPelaData(LocalDate data){
        List<Eventos> eventos = EventoJpaRepository.findByData(data);

        if(eventos.isEmpty()){
            throw  new RecursoNaoEncontradoException("Nenhum evento nessa data");
        }
        return eventos;
    }

    public List<Eventos> buscarEventoPeloStatus(String status){
        Eventos.StatusEventos statusEnum;
        try{
            statusEnum = Eventos.StatusEventos.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e){
            throw new IllegalArgumentException("Status inválido: " + status);
        }
        List<Eventos> eventos = EventoJpaRepository.findByStatus(statusEnum);
        if(eventos.isEmpty()){
            throw  new RecursoNaoEncontradoException("Nenhum evetno com esse status");
        }
        return eventos;
    }



    public Eventos atualizarPorId(Long id, Eventos evento){
        Eventos eventoEntity = EventoJpaRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("nenhum evento encontrado com esse id"));
        eventoEntity.setTitulo(evento.getTitulo());
        eventoEntity.setDescricao(evento.getDescricao());
        eventoEntity.setStatus(evento.getStatus());
        eventoEntity.setData(evento.getData());

        return EventoJpaRepository.save(eventoEntity);
    }

    public void deletarPorId(Long id){
        Eventos evento = EventoJpaRepository.findById(id)
                .orElseThrow(
                        () -> new RecursoNaoEncontradoException("Nenhum event encontrado com esse id"));
        EventoJpaRepository.delete(evento);
    }
}
