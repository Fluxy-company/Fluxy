package school.sptech.iefcbackend.usecase.progressoaula;

import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.ProgressoAula;
import school.sptech.iefcbackend.domain.entity.Usuario;
import school.sptech.iefcbackend.domain.entity.Video;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.ProgressoAulaJpaRepository;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.UsuarioJpaRepository;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.VideoJpaRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProgressoAulaService {

    private final ProgressoAulaJpaRepository repository;
    private final UsuarioJpaRepository UsuarioJpaRepository;
    private final VideoJpaRepository VideoJpaRepository;

    public ProgressoAulaService(ProgressoAulaJpaRepository repository, UsuarioJpaRepository UsuarioJpaRepository, VideoJpaRepository VideoJpaRepository) {
        this.repository = repository;
        this.UsuarioJpaRepository = UsuarioJpaRepository;
        this.VideoJpaRepository = VideoJpaRepository;
    }

    public ProgressoAula marcarConcluida(Long usuarioId, Long videoId, Boolean concluida) {
        Usuario usuario = UsuarioJpaRepository.findById(usuarioId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Usuário não encontrado"));

        Video video = VideoJpaRepository.findById(videoId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Vídeo não encontrado"));

        ProgressoAula progresso = repository.findByUsuarioIdAndVideoId(usuarioId, videoId)
                .orElseGet(() -> {
                    ProgressoAula novo = new ProgressoAula();
                    novo.setUsuario(usuario);
                    novo.setVideo(video);
                    return novo;
                });

        progresso.setConcluida(concluida);
        progresso.setDataAtualizacao(LocalDateTime.now());

        return repository.save(progresso);
    }

    public ProgressoAula salvarAnotacao(Long usuarioId, Long videoId, String anotacao) {
        Usuario usuario = UsuarioJpaRepository.findById(usuarioId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Usuário não encontrado"));

        Video video = VideoJpaRepository.findById(videoId)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Vídeo não encontrado"));

        ProgressoAula progresso = repository.findByUsuarioIdAndVideoId(usuarioId, videoId)
                .orElseGet(() -> {
                    ProgressoAula novo = new ProgressoAula();
                    novo.setUsuario(usuario);
                    novo.setVideo(video);
                    novo.setConcluida(false);
                    return novo;
                });

        progresso.setAnotacao(anotacao);
        progresso.setDataAtualizacao(LocalDateTime.now());

        return repository.save(progresso);
    }

    public List<ProgressoAula> listarPorUsuarioECurso(Long usuarioId, Long cursoId) {
        return repository.findByUsuarioIdAndVideoCursoId(usuarioId, cursoId);
    }
}
