package school.sptech.iefcbackend.web.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.web.bind.annotation.*;
import school.sptech.iefcbackend.web.dto.LoginRequestDTO;
import school.sptech.iefcbackend.web.dto.LoginResponseDTO;
import school.sptech.iefcbackend.domain.exception.CadastroPendenteException;
import school.sptech.iefcbackend.domain.exception.CadastroReprovadoException;
import school.sptech.iefcbackend.domain.enums.Role;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.UsuarioJpaRepository;

import java.time.Instant;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*")
@RestController
@Tag(name = "Login", description = "Controller para autenticação de usuarios")
@RequestMapping("/api/v1")
public class TokenController {

    private final JwtEncoder jwtEncoder;

    private final UsuarioJpaRepository UsuarioJpaRepository;

    private final BCryptPasswordEncoder passwordEncoder;

    public TokenController(JwtEncoder jwtEncoder, UsuarioJpaRepository UsuarioJpaRepository, BCryptPasswordEncoder passwordEncoder) {
        this.jwtEncoder = jwtEncoder;
        this.UsuarioJpaRepository = UsuarioJpaRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Operation(summary = "Login", description = "Método que realiza o login dos usuarios", security = {})
    @ApiResponse(responseCode = "200", description = "Login realizado com sucesso")
    @ApiResponse(responseCode = "403", description = "Sem permissão, login incorreto")
    @ApiResponse(responseCode = "500", description = "Erro de servidor / senha invalida")
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@RequestBody LoginRequestDTO loginRequest){
        var usuario = UsuarioJpaRepository.findByEmail(loginRequest.email())
                .filter(user -> user.loginCorreto(loginRequest, passwordEncoder))
                .orElseThrow(() -> new BadCredentialsException("Email ou senha invalidos."));

        if (usuario.estaPendente()) {
            throw new CadastroPendenteException(
                    "Seu cadastro ainda está aguardando aprovação do administrador.");
        }
        if (usuario.estaReprovado()) {
            throw new CadastroReprovadoException(
                    "Seu cadastro não foi aprovado. Entre em contato com o administrador.");
        }

        var agora = Instant.now();

        var expiraEm = 3600L;

        var escopo = usuario.getRoles()
                .stream()
                .map(Role::getAuthority)
                .collect(Collectors.joining(" "));

        var claims = JwtClaimsSet.builder()
                .issuer("iefcbackend")
                .subject(usuario.getId().toString())
                .issuedAt(agora)
                .expiresAt(agora.plusSeconds(expiraEm))
                .claim("scope", escopo)
                .build();

        var jwtValor = jwtEncoder.encode(JwtEncoderParameters.from(claims)).getTokenValue();

        return  ResponseEntity.ok(new LoginResponseDTO(jwtValor, expiraEm));
    }
}
