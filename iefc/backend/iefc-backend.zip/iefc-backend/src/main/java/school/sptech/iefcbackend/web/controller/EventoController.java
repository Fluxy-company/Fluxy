package school.sptech.iefcbackend.web.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import school.sptech.iefcbackend.domain.entity.Eventos;
import school.sptech.iefcbackend.usecase.evento.EventoService;

import java.time.LocalDate;
import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/eventos")
@Tag(name = "Eventos", description = "Controller para criar, buscar, editar e deletar eventos")
public class EventoController {

    private final EventoService eventoService;

    public EventoController(EventoService eventoService) {
        this.eventoService = eventoService;
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('SCOPE_ROLE_COLABORADOR', 'SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Para criar eventos", description = "Método que cria os eventos")
    @ApiResponse(responseCode = "201", content = @Content(schema = @Schema(implementation = Eventos.class)), description = "Eventos criado com sucesso")
    @ApiResponse(responseCode = "404", description = "Nenhum evento encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Eventos> criarEvento(@RequestBody Eventos evento) {
        Eventos saved = eventoService.criarEvento(evento);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @GetMapping("/data/{data}")
    @PreAuthorize("hasAnyAuthority('SCOPE_ROLE_ALUNO', 'SCOPE_ROLE_COLABORADOR', 'SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Busca eventos pela data", description = "Método que busca os eventos pela data")
    @ApiResponse(responseCode = "200", description = "Eventos retornados com sucesso")
    @ApiResponse(responseCode = "400", description = "Não encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<List<Eventos>> buscarPelaData(
            @PathVariable("data") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data) {
        return ResponseEntity.ok(eventoService.buscarEventoPelaData(data));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyAuthority('SCOPE_ROLE_ALUNO', 'SCOPE_ROLE_COLABORADOR', 'SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Busca eventos pela data", description = "Método que busca os eventos pelos status")
    @ApiResponse(responseCode = "200", description = "Eventos retornados com sucesso")
    @ApiResponse(responseCode = "400", description = "Não encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<List<Eventos>> buscarPeloStatus(@PathVariable("status") String status) {
        return ResponseEntity.ok(eventoService.buscarEventoPeloStatus(status));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Edita o evento pelo id", description = "Método que edita o evento pelo id")
    @ApiResponse(responseCode = "200", description = "video editado com sucesso")
    @ApiResponse(responseCode = "400", description = "Não encontrado")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Eventos> atualizarEventoPorId(@Valid @PathVariable Long id, @RequestBody Eventos eventos) {
        return ResponseEntity.ok(eventoService.atualizarPorId(id, eventos));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_ROLE_ADMIN')")
    @Operation(summary = "Deletar eventos pelo id", description = "Método que deleta os eventos id")
    @ApiResponse(responseCode = "200", description = "Evento deletada com sucesso")
    @ApiResponse(responseCode = "404", description = "Sem eventos nesse id")
    @ApiResponse(responseCode = "500", description = "Erro de servidor")
    public ResponseEntity<Void> deletarPorId(@PathVariable("id") Long id) {
        eventoService.deletarPorId(id);
        return ResponseEntity.noContent().build();
    }
}
