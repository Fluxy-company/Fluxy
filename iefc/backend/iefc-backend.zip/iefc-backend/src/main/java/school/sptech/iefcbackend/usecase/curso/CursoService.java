package school.sptech.iefcbackend.usecase.curso;

import org.springframework.stereotype.Service;
import school.sptech.iefcbackend.domain.exception.RecursoNaoEncontradoException;
import school.sptech.iefcbackend.domain.entity.Curso;
import school.sptech.iefcbackend.infrastructure.persistence.jpa.CursoJpaRepository;

import java.util.List;

@Service
public class CursoService {

    private final CursoJpaRepository repository;

    public CursoService(CursoJpaRepository repository) {
        this.repository = repository;
    }

    public List<Curso> Listar(){
        return repository.findAll();
    }

    public List<Curso> listarPorTema(Long temaId){
        return repository.findByTemaId(temaId);
    }

    public Curso postar(Curso curso){
        Curso cursoNovo = new Curso();
        cursoNovo.setDescricao(curso.getDescricao());
        cursoNovo.setTitulo(curso.getTitulo());
        cursoNovo.setInstrutor(curso.getInstrutor());
        cursoNovo.setVideoId(curso.getVideoId());
        cursoNovo.setTema(curso.getTema());
        cursoNovo.setEmpresa(curso.getEmpresa());
        return repository.save(cursoNovo);
    }

    public Curso buscarPorId(Long id){
        return repository.findById(id).orElseThrow(() -> new RecursoNaoEncontradoException("Não foi possível encontrar o curso desejado"));
    }

    public void delete(Long id){
        repository.delete(buscarPorId(id));
    }

    public Curso atualizar(Long id, Curso curso){
        Curso cursoNovo = buscarPorId(id);
        cursoNovo.setEmpresa(curso.getEmpresa());
        cursoNovo.setDescricao(curso.getDescricao());
        cursoNovo.setTitulo(curso.getTitulo());
        cursoNovo.setInstrutor(curso.getInstrutor());
        cursoNovo.setVideoId(curso.getVideoId());
        cursoNovo.setTema(curso.getTema());
        return repository.save(cursoNovo);
    }
}
